import React, { useRef } from 'react';
import { services } from '../constants/data';
import ServiceCard from './ServiceCard';
import { useInView } from '../hooks/useInView';

const Services: React.FC = () => {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { threshold: 0.1 });
  
  return (
    <section id="services" className="py-20 bg-gray-100">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="section-title text-center mx-auto after:left-1/2 after:-translate-x-1/2">
            Nossos Serviços
          </h2>
          <p className="text-navy-700">
            Oferecemos soluções completas para transporte e assistência de motocicletas de luxo 
            e alta performance, garantindo sempre a máxima segurança e cuidado.
          </p>
        </div>
        
        <div 
          ref={ref}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {services.map((service, index) => (
            <div 
              key={service.id}
              className={`transition-all duration-700 transform ${
                isInView 
                  ? 'opacity-100 translate-y-0' 
                  : 'opacity-0 translate-y-10'
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <ServiceCard 
                title={service.title} 
                description={service.description} 
                icon={service.icon}
                delay={index * 100}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;