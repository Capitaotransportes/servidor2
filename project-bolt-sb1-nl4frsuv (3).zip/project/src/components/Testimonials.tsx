import React, { useRef, useState } from 'react';
import { testimonials } from '../constants/data';
import { User, ChevronLeft, ChevronRight } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const Testimonials: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { threshold: 0.1 });
  
  const nextTestimonial = () => {
    setActiveIndex((prevIndex) => 
      prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
    );
  };
  
  const prevTestimonial = () => {
    setActiveIndex((prevIndex) => 
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
  };
  
  return (
    <section className="py-20 bg-gray-50">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="section-title text-center mx-auto after:left-1/2 after:-translate-x-1/2">
            O Que Dizem Nossos Clientes
          </h2>
          <p className="text-navy-700">
            A satisfação de nossos clientes é o nosso maior patrimônio. Confira alguns depoimentos.
          </p>
        </div>
        
        <div 
          ref={ref}
          className={`max-w-4xl mx-auto relative transition-all duration-1000 ${
            isInView ? 'opacity-100 transform-none' : 'opacity-0 translate-y-10'
          }`}
        >
          <div className="bg-white rounded-xl shadow-lg p-8 md:p-10 relative">
            <div className="absolute -top-5 left-1/2 transform -translate-x-1/2 bg-navy-600 rounded-full p-3">
              <User className="w-8 h-8 text-white" />
            </div>
            
            <div className="mt-4 text-center">
              <blockquote className="text-lg md:text-xl italic text-gray-700 mb-6">
                "{testimonials[activeIndex].content}"
              </blockquote>
              <div className="font-semibold text-navy-900">{testimonials[activeIndex].name}</div>
              <div className="text-sm text-gray-600">{testimonials[activeIndex].role}</div>
            </div>
            
            <div className="flex justify-center mt-8 space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  className={`w-3 h-3 rounded-full transition-all ${
                    index === activeIndex ? 'bg-navy-600 scale-125' : 'bg-gray-300'
                  }`}
                  onClick={() => setActiveIndex(index)}
                  aria-label={`Ver depoimento ${index + 1}`}
                />
              ))}
            </div>
          </div>
          
          <div className="absolute top-1/2 -translate-y-1/2 left-0 -ml-4 md:-ml-6">
            <button 
              className="bg-white rounded-full p-2 shadow-lg hover:bg-navy-50 transition-colors"
              onClick={prevTestimonial}
              aria-label="Depoimento anterior"
            >
              <ChevronLeft className="w-6 h-6 text-navy-600" />
            </button>
          </div>
          
          <div className="absolute top-1/2 -translate-y-1/2 right-0 -mr-4 md:-mr-6">
            <button 
              className="bg-white rounded-full p-2 shadow-lg hover:bg-navy-50 transition-colors"
              onClick={nextTestimonial}
              aria-label="Próximo depoimento"
            >
              <ChevronRight className="w-6 h-6 text-navy-600" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;