# Capitão Transportes

Site institucional da Capitão Transportes, especializada em transporte de motocicletas para todo o Brasil.

## 🚀 Sobre

Empresa especializada no transporte de motocicletas, atendendo todo o Brasil com serviços de:
- Transporte de motos para todo o Brasil
- Socorro e remoção emergencial
- Transporte para oficinas mecânicas
- Apoio logístico para viagens

## 💻 Tecnologias

- React
- TypeScript
- Tailwind CSS
- Vite
- Lucide React

## 🛠️ Instalação

```bash
# Clone o repositório
git clone https://github.com/Capitaotransportes/servidor.git

# Entre no diretório
cd servidor

# Instale as dependências
npm install

# Inicie o servidor de desenvolvimento
npm run dev
```

## 📝 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 📞 Contato

Capitão Transportes - [Website](https://capitaotransportes.com.br)

Email: contato@capitaotransportes.com.br
Telefone: (11) 99999-9999