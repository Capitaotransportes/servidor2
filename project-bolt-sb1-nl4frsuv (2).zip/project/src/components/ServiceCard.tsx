import React from 'react';
import { getIconComponent } from '../constants/data';

interface ServiceCardProps {
  title: string;
  description: string;
  icon: string;
  delay?: number;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ title, description, icon, delay = 0 }) => {
  const IconComponent = getIconComponent(icon);
  
  return (
    <div 
      className="bg-white rounded-lg shadow-lg p-6 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 group"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="mb-4 p-4 bg-navy-50 rounded-full inline-block group-hover:bg-navy-600 transition-colors duration-300">
        <IconComponent className="w-8 h-8 text-navy-600 group-hover:text-white transition-colors duration-300" />
      </div>
      <h3 className="text-xl font-semibold mb-3 text-navy-900">{title}</h3>
      <p className="text-gray-700">{description}</p>
    </div>
  );
};

export default ServiceCard;