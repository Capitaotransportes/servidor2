/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          50: '#f0f3f9',
          100: '#d0dcec',
          200: '#a3b8d9',
          300: '#7694c5',
          400: '#4970b2',
          500: '#365d9b',
          600: '#1c4b85',
          700: '#12396e',
          800: '#092858',
          900: '#051841',
        },
        brand: {
          blue: '#0088FF',
          red: '#FF0000',
          black: '#000000',
        },
        gray: {
          metal: '#C0C0C0',
          dark: '#2D3748',
          light: '#F7FAFC',
        }
      },
      fontFamily: {
        sans: ['Montserrat', 'sans-serif'],
      },
      backgroundImage: {
        'hero-pattern': "linear-gradient(rgba(5, 24, 65, 0.75), rgba(5, 24, 65, 0.75)), url('https://images.pexels.com/photos/2760243/pexels-photo-2760243.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')",
      },
    },
  },
  plugins: [],
};